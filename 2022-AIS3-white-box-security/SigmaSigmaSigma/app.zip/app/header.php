<?php
error_reporting(0);
header("Content-Security-Policy: script-src 'none'; img-src 'self' https://i.imgur.com");
include("lib/class_article.php");
include("lib/class_articlebody.php");
include("lib/class_avatar.php");
include("lib/class_cookie.php");
include("lib/class_user.php");
include("lib/class_debug.php");
include("lib/class_filemanager.php");
include("lib/lib_common.php");